package com.example.dws2022v1.teams;


import com.example.dws2022v1.users.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.example.dws2022v1.users.User;


@Controller
@RequestMapping("/teams")
public class TeamController {

    @Autowired
    private TeamService teams;
    @Autowired
    private UserService users;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/")
    public String showAllTeams(Model model, @RequestParam(required = false) String name) {
        loginDisplay(model);
        if (name != null) {
            model.addAttribute("teams", teams.teamsByName(name));
        } else {
            model.addAttribute("teams", teams.getValues());
        }
        return "allTeams";
    }

    @GetMapping("/create")
    public String showCreate(Model model){
        loginDisplay(model);
        return "create-team";
    }

    @PostMapping("/create")
    public String createTeam(@RequestParam String name, @RequestParam String password, @RequestParam String motto, Model model){
        loginDisplay(model);
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();
        if((users.getValue(username)==null)||(teams.getValue(name)!=null)) {
            model.addAttribute("error",true);
            return "create-team";
        }
        Team newTeam = new Team(name, passwordEncoder.encode(password), motto);
        User captain = users.getValue(username);
        newTeam.addMember(captain);
        teams.addTeam(newTeam);
        captain.setTeam(newTeam);
        users.addUser(captain);
        return "index";
    }

    @GetMapping("/join")
    public String showJoin(Model model){
        loginDisplay(model);
        return "join-team";
    }

    @PostMapping("/join")
    public String joinTeam(@RequestParam String name, @RequestParam String password, Model model){
        loginDisplay(model);
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();
        Team editedTeam=teams.getValue(name);
        User newMember;
        if (username != null) {
            newMember = users.getValue(username);
        } else {
            newMember = null;
        }
        if (newMember==null) {
            model.addAttribute("notRegistered",true);
            return "register-user";
        } else if(editedTeam==null) {
            model.addAttribute("notRegistered",true);
            return "create-team";
        } else if(!passwordEncoder.matches(password, editedTeam.getPassword())) {
            model.addAttribute("error",true);
            return "join-team";
        } else if(!editedTeam.addMember(newMember)) {
            model.addAttribute("fullTeam",true);
            return "join-team";
        } else {
            model.addAttribute("team", teams.getValue(name));
            newMember.setTeam(editedTeam);
            users.addUser(newMember);
            teams.addTeam(editedTeam);
            return "team";
        }
    }

    @GetMapping("/{name}")
    public String showTeam(Model model,@PathVariable String name) {
        if(!checkSession(name)) {
            model.addAttribute("403", name);
            return "error";
        }
        Team checkTeam = teams.getValue(name);
        if (checkTeam != null) {
            model.addAttribute("team", checkTeam);
            if (!checkTeam.getTournaments().isEmpty()) {
                model.addAttribute("inscribedInTournaments", checkTeam);
            }
            if (checkTeam.getMotto() != null) {
                model.addAttribute("showMotto", checkTeam);
            }
            loginDisplay(model);
            return "team";
        }
        return "error";
    }

    @PostMapping("/{name}/editPass")
    public String editPassword(Model model,@PathVariable String name,@RequestParam String password) {
        if(!checkSession(name)) {
            model.addAttribute("403", name);
            return "error";
        }
        Team editedTeam=teams.getValue(name);
        if (editedTeam!=null) {
            editedTeam.setPassword(password);
            teams.addTeam(editedTeam);
            model.addAttribute("team", editedTeam);
            if (!editedTeam.getTournaments().isEmpty()) {
                model.addAttribute("inscribedInTournaments", editedTeam);
            }
            if (editedTeam.getMotto() != null) {
                model.addAttribute("showMotto", editedTeam);
            }
            loginDisplay(model);
            return "team";
        }
        return "error";
    }

    @PostMapping("/{name}/editMotto")
    public String editMotto(Model model,@PathVariable String name,@RequestParam String motto) {
        System.out.println("a");
        if(!checkSession(name)) {
            model.addAttribute("403", name);
            return "error";
        }
        Team editedTeam=teams.getValue(name);
        if (editedTeam!=null) {
            editedTeam.setMotto(motto);
            teams.addTeam(editedTeam);
            model.addAttribute("team", editedTeam);
            if (!editedTeam.getTournaments().isEmpty()) {
                model.addAttribute("inscribedInTournaments", editedTeam);
            }
            if (editedTeam.getMotto() != null) {
                model.addAttribute("showMotto", editedTeam);
            }
            loginDisplay(model);
            return "team";
        }
        return "error";
    }
    //WARNING: removing a team will also delete any link to its members and tournaments.

    @PostMapping("/{name}/delete")
    public String deleteTeam(@PathVariable String name, Model model) {
        if(!checkSession(name)) {
            model.addAttribute("403", name);
            return "error";
        }
        if(teams.getValue(name)!=null) {
            teams.removeTeam(name);
            loginDisplay(model);
            return "index";
        }
        return "error";
    }

    private void loginDisplay(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_USER"))) {
            model.addAttribute("isLogged", true);
            if (auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
                model.addAttribute("admin", true);
            } else {
                model.addAttribute("username", users.getValue(auth.getName()));
            }
        }
    }

    private boolean checkSession(String teamName){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!(auth instanceof AnonymousAuthenticationToken)) {
            return auth.getName() != null
                    && ((users.getValue(auth.getName()).getTeam() != null && users.getValue(auth.getName()).getTeam().getName().equals(teamName))
                            || auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN")));
        }
        return false;
    }

}