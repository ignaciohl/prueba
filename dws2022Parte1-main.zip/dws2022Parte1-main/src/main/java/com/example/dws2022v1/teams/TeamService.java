package com.example.dws2022v1.teams;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class TeamService {

    @Autowired
    private TeamRepository teamRepository;

    public List<Team> teamsByName(String name) {
        return teamRepository.teamsByName(name);
    }

    public void addTeam(Team team) {
        teamRepository.save(team);
    }

    public Collection<Team> getValues() {
        return teamRepository.findAll();
    }

    public Team removeTeam(String name){
        Team team=getValue(name);
        if(team!=null) teamRepository.delete(team);
        return team;
    }

    public Team getValue(String name) {
        Optional<Team> value = teamRepository.findById(name);
        return value.isPresent()?value.get():null;
    }

}
