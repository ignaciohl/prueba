package com.example.dws2022v1.users;

import com.example.dws2022v1.teams.TeamService;
import com.fasterxml.jackson.annotation.JsonView;
import org.owasp.html.Sanitizers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import com.example.dws2022v1.teams.Team;

import java.util.Collection;

@RequestMapping("/api/users")
@RestController
public class UserRESTController {
    @Autowired
    private UserService users;
    @Autowired
    private TeamService teams;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @JsonView(User.UserView.class)
    @GetMapping("/")
    public Collection<User> getUsers(){
        return users.getValues();
    }

    @JsonView(User.UserView.class)
    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public User createUser(@RequestBody User user){
        setupUser(user);
        return user;
    }

    @JsonView(User.UserView.class)
    @GetMapping("/{name}")
    public ResponseEntity<User> getUser(@PathVariable String name){
        if(!checkSession(name)) return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        User user = users.getValue(name);
        if (user != null) {
            return new ResponseEntity<>(user, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @JsonView(User.UserView.class)
    @DeleteMapping("/{name}")
    public ResponseEntity<User> deleteUser(@PathVariable String name){
        if(!checkSession(name)) return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        User user = users.removeUser(name);
        if (user != null) {
            Team team=user.getTeam();
            if(team.getUsers().size()==0){
                teams.removeTeam(team.getName());
            }
            return new ResponseEntity<>(user, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @JsonView(User.UserView.class)
    @PutMapping("/{name}")
    public ResponseEntity<User> editUser(@PathVariable String name, @RequestBody User editedUser){
        if(!checkSession(name)) return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        User user = users.getValue(name);
        if (user != null) {
            setupUser(editedUser);
            return new ResponseEntity<>(editedUser, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    private void setupUser(@RequestBody User editedUser) {
        editedUser.setSelfDescription(Sanitizers.FORMATTING.sanitize(editedUser.getSelfDescription()));
        if(editedUser.getTeam()!=null&&editedUser.getTeam().getName()!=null) {
            Team editedTeam = teams.getValue(editedUser.getTeam().getName());
            if (editedTeam != null) {
                editedTeam.addMember(editedUser);
                teams.addTeam(editedTeam);
            }else{
                editedUser.setTeam(null);
            }
        }else{
            editedUser.setTeam(null);
        }
        editedUser.setPassword(passwordEncoder.encode(editedUser.getPassword()));
        users.addUser(editedUser);
    }

    private boolean checkSession(String name){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!(auth instanceof AnonymousAuthenticationToken)) {
            return auth.getName() != null && (auth.getName().equals(name) || auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN")));
        }
        return false;
    }
}
