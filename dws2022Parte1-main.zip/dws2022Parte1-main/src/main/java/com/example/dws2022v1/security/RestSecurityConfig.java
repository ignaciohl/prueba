package com.example.dws2022v1.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.security.SecureRandom;

@Configuration
@Order(1)
public class RestSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    RepositoryUserDetailsService userDetailsService;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.antMatcher("/api/**");

        http.authorizeRequests().antMatchers(HttpMethod.GET, "/api/users/").permitAll();
        http.authorizeRequests().antMatchers(HttpMethod.POST, "/api/users/").permitAll();
        http.authorizeRequests().antMatchers(HttpMethod.GET, "/api/users/{name}").hasAnyRole("USER","ADMIN");
        http.authorizeRequests().antMatchers(HttpMethod.POST, "/api/users/{name}").hasAnyRole("USER","ADMIN");
        http.authorizeRequests().antMatchers(HttpMethod.PUT, "/api/users/{name}").hasAnyRole("USER","ADMIN");
        http.authorizeRequests().antMatchers(HttpMethod.DELETE, "/api/users/{name}").hasAnyRole("USER","ADMIN");

        http.authorizeRequests().antMatchers(HttpMethod.GET, "/api/teams/").permitAll();
        http.authorizeRequests().antMatchers(HttpMethod.POST, "/api/teams/").hasAnyRole("USER");
        http.authorizeRequests().antMatchers(HttpMethod.GET, "/api/teams/{name}").permitAll();
        http.authorizeRequests().antMatchers(HttpMethod.POST, "/api/teams/{name}").hasAnyRole("USER","ADMIN");
        http.authorizeRequests().antMatchers(HttpMethod.PUT, "/api/teams/{name}").hasAnyRole("USER","ADMIN");
        http.authorizeRequests().antMatchers(HttpMethod.DELETE, "/api/teams/{name}").hasAnyRole("USER","ADMIN");

        http.authorizeRequests().antMatchers(HttpMethod.GET, "/api/tournaments/").permitAll();
        http.authorizeRequests().antMatchers(HttpMethod.POST, "/api/tournaments/").hasAnyRole("ADMIN");
        http.authorizeRequests().antMatchers(HttpMethod.GET, "/api/tournaments/{name}").permitAll();
        http.authorizeRequests().antMatchers(HttpMethod.POST, "/api/tournaments/{name}").hasAnyRole("ADMIN");
        http.authorizeRequests().antMatchers(HttpMethod.PUT, "/api/tournaments/{name}").hasAnyRole("ADMIN");
        http.authorizeRequests().antMatchers(HttpMethod.DELETE, "/api/tournaments/{name}").hasAnyRole("ADMIN");

        http.httpBasic();
        http.formLogin().disable();
        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        http.csrf().disable();
    }

}
