package com.example.dws2022v1.tournaments;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;

public interface TournamentRepository extends JpaRepository<Tournament, String> {
    @Query(value = "select * from tournament where (tournament_name LIKE CONCAT('%', ?1, '%'))", nativeQuery = true)
    List<Tournament> tournamentsByName(@Param("name") String name);
    @Query(value = "select * from tournament where UPPER(tournament.institution)=?1", nativeQuery = true)
    List<Tournament> tournamentsByInstitution(@Param("institution") String institution);
    @Query(value = "select * from tournament where tournament.start_date>=?1 and tournament.finish_date<=?2", nativeQuery = true)
    List<Tournament> tournamentsByDateRange(@Param("startDate") Date startDate, @Param("finishDate") Date finishDate);
}
