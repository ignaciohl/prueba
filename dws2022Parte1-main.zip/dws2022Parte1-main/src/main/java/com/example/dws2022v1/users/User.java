package com.example.dws2022v1.users;

import com.example.dws2022v1.teams.Team;
import com.example.dws2022v1.tournaments.Tournament;
import com.fasterxml.jackson.annotation.JsonView;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@Entity

public class User {

    public interface UserView {
    }

    @JsonView({UserView.class, Tournament.TournamentView.class, Team.TeamView.class})
    @Id
    private String username;

    private String password;
    @JsonView(UserView.class)
    private String selfDescription;

    @ElementCollection(fetch = FetchType.EAGER)
    private List<String> roles;

    @JsonView(UserView.class)
    @ManyToOne
    private Team team;

    public User(String username, String password, List<String> roles) {
        this.username = username;
        this.password = password;
        this.roles = roles;
    }

    public User(String username, String password, String selfDescription) {
        this.username = username;
        this.password = password;
        this.selfDescription = selfDescription;
        roles = new ArrayList<>();
        roles.add("USER");
    }

    public void addRole(String role) {
        roles.add(role);
    }

    public void removeRole(String role) {
        roles.remove(role);
    }

    @PreRemove
    public void onDelete() {
        if (team != null) {
            team.removeUser(this);
        }
    }

    @Override
    public String toString() {
        return username;
        /*
        if (team != null) {
            return "User{" +
                    "name='" + username + '\'' +
                    ", password='" + password + '\'' +
                    ", selfDescription='" + selfDescription + '\'' +
                    ", team=" + team.getName() +
                    '}';
        } else {
            return "User{" +
                    "name='" + username + '\'' +
                    ", password='" + password + '\'' +
                    ", selfDescription='" + selfDescription + '\'' +
                    '}';
        }
        */
    }

}
