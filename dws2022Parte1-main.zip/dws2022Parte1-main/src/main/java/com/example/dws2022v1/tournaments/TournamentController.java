package com.example.dws2022v1.tournaments;

import com.example.dws2022v1.teams.Team;
import com.example.dws2022v1.teams.TeamService;
import com.example.dws2022v1.users.User;
import com.example.dws2022v1.users.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
@RequestMapping("/tournaments")
public class TournamentController {

    @Autowired
    private TournamentService tournaments;
    @Autowired
    private TeamService teams;
    @Autowired
    private UserService users;

    private static final String regex = "^(^(((0[1-9]|1[0-9]|2[0-8])/(0[1-9]|1[012]))|((29|30|31)/(0[13578]|1[02]))|((29|30)/(0[469]|11)))[/](19|[2-9][0-9])\\d\\d$)|(^29/02/(19|[2-9][0-9])(00|04|08|12|16|20|24|28|32|36|40|44|48|52|56|60|64|68|72|76|80|84|88|92|96)$)";

    @GetMapping("/")
    public String showAllTournaments(Model model){
        model.addAttribute("tournaments", tournaments.getValues());
        loginDisplay(model);
        return "allTournaments";
    }

    @GetMapping("/search")
    public String searchTournaments(Model model,
                                    @RequestParam(required = false, name = "name") String name,
                                    @RequestParam(required = false, name = "institution") String institution,
                                    @RequestParam(required = false, name = "startDate") String startDate,
                                    @RequestParam(required = false, name = "finishDate") String finishDate) throws ParseException {
        Date dateStart = null, dateFinish = null;
        if (startDate != null && startDate.matches(regex)) {
            dateStart = new SimpleDateFormat("dd/MM/yyyy").parse(startDate);
        }
        if (finishDate != null && finishDate.matches(regex)) {
            dateFinish = new SimpleDateFormat("dd/MM/yyyy").parse(finishDate);
        }
        if(name.length()==0){
            name=null;
        }
        if(institution.length()==0){
            institution=null;
        }
        if (name == null && institution == null && dateStart == null && dateFinish == null) {
            model.addAttribute("tournaments", tournaments.getValues());
        } else {
            Set<Tournament> tournamentSet = new HashSet<>(tournaments.getValues());
            if (name != null) {
                tournamentSet.retainAll(tournaments.tournamentsByName(name));
            }
            if (institution != null) {
                tournamentSet.retainAll(tournaments.tournamentsByInstitution(institution));
            }
            if (dateStart != null && dateFinish != null) {
                tournamentSet.retainAll(tournaments.tournamentsByDateRange(dateStart, dateFinish));
            }
            List<Tournament> finalList = new LinkedList<>(tournamentSet);
            model.addAttribute("tournaments", finalList);
        }
        loginDisplay(model);
        return "allTournaments";
    }

    @GetMapping("/create")
    public String showCreate(Model model){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
            model.addAttribute("403", true);
            return "error";
        }
        loginDisplay(model);
        return "create-tournament";
    }

    @PostMapping("/create")
    public String createTournament(@RequestParam String name, @RequestParam String institution,
                                   @RequestParam String startDate, @RequestParam String finishDate,
                                   @RequestParam String briefDescription, @RequestParam String code,
                                   Model model){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
            model.addAttribute("403", true);
            return "error";
        }
        loginDisplay(model);
        if((tournaments.getValue(code)!=null)) {
            model.addAttribute("error",true);
            return "create-team";
        }
        if (startDate.matches(regex) && finishDate.matches(regex)) {
            try {
                Date dateStart = new SimpleDateFormat("dd/MM/yyyy").parse(startDate);
                Date dateFinish = new SimpleDateFormat("dd/MM/yyyy").parse(finishDate);
                Tournament newTournament = new Tournament(name, institution.toUpperCase(), dateStart, dateFinish, briefDescription, code);
                tournaments.addTournament(newTournament);
                return "index";
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        model.addAttribute("formatError", true);
        return "create-tournament";
    }

    @GetMapping("/join")
    public String showJoin(Model model){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth.getName() == null) {
            return "error";
        }
        loginDisplay(model);
        if (users.getValue(auth.getName()).getTeam() == null) {
            return "create-team";
        }
        return "join-tournament";
    }

    @PostMapping("/join")
    public String joinTournament(@RequestParam String code, Model model){
        loginDisplay(model);
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String teamname = null;
        User transitionUser = users.getValue(auth.getName());
        if (transitionUser != null) {
            Team transitionTeam = transitionUser.getTeam();
            if (transitionTeam != null) {
                teamname = transitionTeam.getName();
            }
        }
        if (teamname == null) {
            return "error";
        }
        if(!checkSession(teamname)) {
            model.addAttribute("403", teamname);
            return "error";
        }
        Tournament editedTournament = tournaments.getValue(code);
        Team newTeam = teams.getValue(teamname);
        if (newTeam == null) {
            model.addAttribute("error",true);
            return "create-team";
        } else if (editedTournament == null) {
            model.addAttribute("error",true);
            return "join-tournament";
        } else if (!editedTournament.addTeam(newTeam)) {
            model.addAttribute("error",true);
            return "join-tournament";
        } else {
            newTeam.addTournament(editedTournament);
            tournaments.addTournament(editedTournament);
            teams.addTeam(newTeam);
            return "index";
        }
    }

    @GetMapping("/{code}")
    public String showTeam(Model model,@PathVariable String code) {
        Tournament checkTournament = tournaments.getValue(code);
        if (checkTournament != null) {
            model.addAttribute("tournament",checkTournament);
            addAdminOptions(model, checkTournament);
            loginDisplay(model);
            return "tournament";
        }
        return "error";
    }

    @PostMapping("/{code}/editStartDate")
    public String editStartDate(Model model,@PathVariable String code,@RequestParam String startDate) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
            model.addAttribute("403", true);
            return "error";
        }
        loginDisplay(model);
        Tournament editedTournament = tournaments.getValue(code);
        if (editedTournament!=null) {
            if (startDate.matches(regex)) {
                try {
                    Date dateStart = new SimpleDateFormat("dd/MM/yyyy").parse(startDate);
                    editedTournament.setStartDate(dateStart);
                    tournaments.addTournament(editedTournament);
                    model.addAttribute("tournament", editedTournament);
                    addAdminOptions(model, editedTournament);
                    return "tournament";
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        }
        model.addAttribute("dateFormatErrorStart", editedTournament);
        return "tournament";
    }

    @PostMapping("/{code}/editFinishDate")
    public String editFinishDate(Model model,@PathVariable String code,@RequestParam String finishDate) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
            model.addAttribute("403", true);
            return "error";
        }
        Tournament editedTournament = tournaments.getValue(code);
        if (editedTournament!=null) {
            if (finishDate.matches(regex)) {
                try {
                    Date dateStart = new SimpleDateFormat("dd/MM/yyyy").parse(finishDate);
                    editedTournament.setStartDate(dateStart);
                    tournaments.addTournament(editedTournament);
                    model.addAttribute("tournament", editedTournament);
                    addAdminOptions(model, editedTournament);
                    loginDisplay(model);
                    return "tournament";
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        }
        model.addAttribute("dateFormatErrorFinish", editedTournament);
        loginDisplay(model);
        return "tournament";
    }

    @PostMapping("/{code}/editBriefDescription")
    public String editBriefDescription(Model model,@PathVariable String code,@RequestParam String briefDescription) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
            model.addAttribute("403", true);
            return "error";
        }
        Tournament editedTournament = tournaments.getValue(code);
        if (editedTournament!=null) {
            editedTournament.setBriefDescription(briefDescription);
            tournaments.addTournament(editedTournament);
            model.addAttribute("tournament", editedTournament);
            addAdminOptions(model, editedTournament);
            loginDisplay(model);
            return "tournament";
        }
        return "error";
    }

    @PostMapping("/{code}/delete")
    public String deleteTournament(@PathVariable String code, Model model) {
        if(tournaments.getValue(code)!=null) {
            tournaments.removeTournament(code);
            loginDisplay(model);
            return "index";
        }
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
            model.addAttribute("403", true);
            return "error";
        }
        return "error";
    }

    private boolean checkSession(String teamName){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!(auth instanceof AnonymousAuthenticationToken)) {
            return auth.getName() != null && (users.getValue(auth.getName()).getTeam().getName().equals(teamName) || auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN")));
        }
        return false;
    }

    private void loginDisplay(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_USER"))) {
            model.addAttribute("isLogged", true);
            if (auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
                model.addAttribute("admin", true);
            } else {
                model.addAttribute("username", users.getValue(auth.getName()));
            }
        }
    }

    private void addAdminOptions(Model model, Object object) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
            model.addAttribute("adminOptions", object);
        }
    }
}
