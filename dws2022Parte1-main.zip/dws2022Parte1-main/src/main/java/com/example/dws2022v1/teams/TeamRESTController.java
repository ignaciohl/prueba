package com.example.dws2022v1.teams;

import com.example.dws2022v1.users.UserService;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RequestMapping("/api/teams")
@RestController
public class TeamRESTController {
    @Autowired
    private TeamService teams;
    @Autowired
    private UserService users;

    @JsonView(Team.TeamView.class)
    @GetMapping("/")
    public Collection<Team> getTeams(){
        return teams.getValues();
    }

    @JsonView(Team.TeamView.class)
    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public Team createTeam(@RequestBody Team team){
        teams.addTeam(team);
        return team;
    }

    @JsonView(Team.TeamView.class)
    @GetMapping("/{name}")
    public ResponseEntity<Team> getTeam(@PathVariable String name){
        if(!checkSession(name)) return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        Team team = teams.getValue(name);
        if (team != null) {
            return new ResponseEntity<>(team, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @JsonView(Team.TeamView.class)
    @DeleteMapping("/{name}")
    public ResponseEntity<Team> deleteTeam(@PathVariable String name){
        if(!checkSession(name)) return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        Team team = teams.removeTeam(name);
        if (team != null) {
            return new ResponseEntity<>(team, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @JsonView(Team.TeamView.class)
    @PutMapping("/{name}")
    public ResponseEntity<Team> editTeam(@PathVariable String name, @RequestBody Team editedTeam){
        if(!checkSession(name)) return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        Team team = teams.getValue(name);
        if (team != null) {
            teams.addTeam(editedTeam);
            return new ResponseEntity<>(editedTeam, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    private boolean checkSession(String teamName){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!(auth instanceof AnonymousAuthenticationToken)) {
            return auth.getName() != null
                    && ((users.getValue(auth.getName()).getTeam() != null && users.getValue(auth.getName()).getTeam().getName().equals(teamName))
                    || auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN")));
        }
        return false;
    }
}
