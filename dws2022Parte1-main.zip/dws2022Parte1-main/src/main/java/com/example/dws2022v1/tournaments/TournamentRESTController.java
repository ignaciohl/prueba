package com.example.dws2022v1.tournaments;

import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RequestMapping("/api/tournaments")
@RestController
public class TournamentRESTController {
    @Autowired
    private TournamentService tournaments;

    @JsonView(Tournament.TournamentView.class)
    @GetMapping("/")
    public Collection<Tournament> getTournaments(){
        return tournaments.getValues();
    }

    @JsonView(Tournament.TournamentView.class)
    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public Tournament createTournament(@RequestBody Tournament tournament){
        tournaments.addTournament(tournament);
        return tournament;
    }

    @JsonView(Tournament.TournamentView.class)
    @GetMapping("/{code}")
    public ResponseEntity<Tournament> getTournament(@PathVariable String code){
        Tournament tournament = tournaments.getValue(code);
        if (tournament != null) {
            return new ResponseEntity<>(tournament, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @JsonView(Tournament.TournamentView.class)
    @DeleteMapping("/{code}")
    public ResponseEntity<Tournament> deleteTournament(@PathVariable String code){
        Tournament tournament = tournaments.removeTournament(code);
        if (tournament != null) {
            return new ResponseEntity<>(tournament, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @JsonView(Tournament.TournamentView.class)
    @PutMapping("/{code}")
    public ResponseEntity<Tournament> editTournament(@PathVariable String code, @RequestBody Tournament editedTournament){
        Tournament tournament = tournaments.getValue(code);
        if (tournament != null) {
            tournaments.addTournament(editedTournament);
            return new ResponseEntity<>(editedTournament, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
