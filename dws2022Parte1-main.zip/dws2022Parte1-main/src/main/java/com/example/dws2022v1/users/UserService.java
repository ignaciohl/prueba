package com.example.dws2022v1.users;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public void addUser(User user) {
        userRepository.save(user);
    }

    public User removeUser(String name){
        User user=this.getValue(name);
        if(user!=null) userRepository.delete(user);
        return user;
    }

    public Collection<User> getValues() {
        return userRepository.findAll();
    }

    public User getValue(String name) {
        Optional<User> value = userRepository.findById(name);
        return value.isPresent()?value.get():null;
    }
}
