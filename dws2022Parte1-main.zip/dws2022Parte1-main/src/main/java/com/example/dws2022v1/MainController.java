package com.example.dws2022v1;

import com.example.dws2022v1.users.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    @Autowired
    UserService users;

    @GetMapping("/")
    public String mainPage(Model model){
        loginDisplay(model);
        return "index";
    }

    @GetMapping("/stopwatch")
    public String stopwatch(Model model) {
        loginDisplay(model);
        return "stopwatch";
    }

    @GetMapping("/admin")
    public String adminPage() {
        return "admin";
    }

    private void loginDisplay(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_USER"))) {
            model.addAttribute("isLogged", true);
            if (auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
                model.addAttribute("admin", true);
            } else {
                model.addAttribute("username", users.getValue(auth.getName()));
            }
        }
    }
}
