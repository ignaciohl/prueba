package com.example.dws2022v1.security;

import com.example.dws2022v1.users.User;
import com.example.dws2022v1.users.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

@Component
public class DatabaseUsersLoader {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @PostConstruct
    private void initDatabase() {
        List<String> adminRoles = new ArrayList<>();
        adminRoles.add("ADMIN");
        adminRoles.add("USER");
        userRepository.save(new User("admin", passwordEncoder.encode("0Eu3$mC9^Zt3%DCaR8Pt"), adminRoles));
    }
}
