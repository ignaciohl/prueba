package com.example.dws2022v1.tournaments;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.data.jpa.repository.Query;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;


@Service
public class TournamentService {

    @Autowired
    private TournamentRepository tournamentRepository;

    public List<Tournament> tournamentsByName(String name) {
        return tournamentRepository.tournamentsByName(name);
    }

    public List<Tournament> tournamentsByInstitution(String institution) {
        return tournamentRepository.tournamentsByInstitution(institution);
    }

    public List<Tournament> tournamentsByDateRange(Date startDate, Date finishDate) {
        return tournamentRepository.tournamentsByDateRange(startDate, finishDate);
    }

    public void addTournament(Tournament tournament) {
        tournamentRepository.save(tournament);
    }

    public Collection<Tournament> getValues() {
        return tournamentRepository.findAll();
    }

    public Tournament removeTournament(String code){
        Tournament tournament=getValue(code);
        if(tournament!=null) tournamentRepository.delete(tournament);
        return tournament;
    }

    public Tournament getValue(String code) {
        Optional<Tournament> value = tournamentRepository.findById(code);
        return value.isPresent()?value.get():null;
    }

}
