package com.example.dws2022v1.teams;

import com.example.dws2022v1.tournaments.Tournament;
import com.example.dws2022v1.users.User;
import com.fasterxml.jackson.annotation.JsonView;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.stream.Collectors;
import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Data
@NoArgsConstructor
@Entity
public class Team {

    public interface TeamView{}

    @JsonView({TeamView.class,User.UserView.class,Tournament.TournamentView.class})
    @Id
    private String name;

    private String password;
    @JsonView({TeamView.class,Tournament.TournamentView.class})
    private String motto;

    @JsonView(TeamView.class)
    @ManyToMany
    private List<Tournament> tournaments = new ArrayList<>();
    private final static int maxUsers = 4;

    @JsonView({TeamView.class,Tournament.TournamentView.class})
    @OneToMany()
    private List<User> users = new ArrayList<>();

    public Team (String name, String password, String motto) {
        this.name = name;
        this.password = password;
        this.motto = motto;
    }

    @PreRemove
    public void onDelete(){
        for(User u : users){
            u.setTeam(null);
        }
        for(Tournament t : tournaments){
            t.removeTeam(this);
        }
    }

    public boolean addMember(User user) {
        if((users.size()<maxUsers)&&!users.contains(user)){
            users.add(user);
            return true;
        }
        return false;
    }


    public void addTournament (Tournament tournament){
        tournaments.add(tournament);
    }

    public void removeTournament(Tournament tournament){
        tournaments.remove(tournament);
    }

    public void removeUser(User user){
        users.remove(user);
    }

    @Override
    public String toString() {
        return "Team{" +
                "name='" + name + '\'' +
                ", motto='" + motto + '\'' +
                ", tournaments=" + tournaments.stream().map(Tournament::getCode).toList() +
                ", users=" + users.stream().map(User::getUsername).toList() +   // Solve overflow
                '}';
    }

    @Override
    public boolean equals(Object o) { //Compares by username
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Team team = (Team) o;
        return Objects.equals(name, team.name);
    }

}
