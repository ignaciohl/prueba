package com.example.dws2022v1.users;


import com.example.dws2022v1.teams.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;
import com.example.dws2022v1.teams.Team;
import org.owasp.html.Sanitizers;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.authentication.AnonymousAuthenticationToken;

@Controller
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService users;

    @Autowired
    private TeamService teams;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/register")
    public String showRegister(){
        return "register-user";
    }

    @PostMapping("/register")
    public String registerUser(@RequestParam String name,@RequestParam String password,@RequestParam String selfDescription,Model model){
        if(users.getValue(name)!=null) {
            model.addAttribute("error",true);
            return "register-user";
        }
        User newUser = new User(name, passwordEncoder.encode(password), Sanitizers.FORMATTING.sanitize(selfDescription));
        users.addUser(newUser);
        loginDisplay(model);
        return "index";
    }

    @GetMapping("/login")
    public String showLogin(){
        return "login-user";
    }

    @PostMapping("/login")
    public String loginUser(@RequestParam String name,@RequestParam String password, Model model){
        User user=users.getValue(name);
        if(user==null) {
            model.addAttribute("notRegistered",true);
            return "register-user";
        }else if(passwordEncoder.matches(password, user.getPassword())) {
            model.addAttribute("user", users.getValue(name));
            if (user.getTeam()!= null) {
                model.addAttribute("hasATeam", users.getValue(name));
            }
            if (user.getRoles().contains("ADMIN")) {
                return "admin";
            }
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
                model.addAttribute("admin", true);
            } else {
                model.addAttribute("username", auth.getName());
            }
            return "user";
        } else {
            model.addAttribute("error",true);
            return "login-user";
        }
    }

    @GetMapping("/{name}")
    public String showUser(Model model,@PathVariable String name){
        if(!checkSession(name)) {
            model.addAttribute("403", name);
            return "error";   // if session is not supposed to enter here return error
        }
        User checkUser = users.getValue(name);
        if (checkUser != null) {
            model.addAttribute("user", checkUser);
            if (checkUser.getSelfDescription() != null) {
                model.addAttribute("description", checkUser);
            }
            if (checkUser.getTeam()!= null) {
                model.addAttribute("hasATeam", checkUser);
            }
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
                model.addAttribute("admin", true);
            } else {
                model.addAttribute("username", auth.getName());
            }
            return "user";
        }
        return "error";
    }

    @PostMapping("/{name}/editPass")
    public String editPassword(Model model,@PathVariable String name,@RequestParam String password){
        if(!checkSession(name)) {
            model.addAttribute("403", name);
            return "error";
        }
        User editedUser=users.getValue(name);
        if(editedUser!=null) {
            editedUser.setPassword(password);
            users.addUser(editedUser);
            model.addAttribute("user", editedUser);
            if (editedUser.getSelfDescription() != null) {
                model.addAttribute("description", editedUser);
            }
            if (editedUser.getTeam()!= null) {
                model.addAttribute("hasATeam", users.getValue(name));
            }
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
                model.addAttribute("admin", true);
            } else {
                model.addAttribute("username", auth.getName());
            }
            return "user";
        }
        return "error";
    }

    @PostMapping("/{name}/editDesc")
    public String editDescription(Model model,@PathVariable String name,@RequestParam String selfDescription){
        System.out.println(selfDescription);
        if(!checkSession(name)) {
            model.addAttribute("403", name);
            return "error";
        }
        User editedUser=users.getValue(name);
        if(editedUser!=null) {
            editedUser.setSelfDescription(Sanitizers.FORMATTING.sanitize(selfDescription));
            users.addUser(editedUser);
            model.addAttribute("user", editedUser);
            if (editedUser.getSelfDescription() != null) {
                model.addAttribute("description", editedUser);
            }
            if (editedUser.getTeam()!= null) {
                model.addAttribute("hasATeam", users.getValue(name));
            }
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
                model.addAttribute("admin", true);
            } else {
                model.addAttribute("username", auth.getName());
            }
            return "user";
        }
        return "error";
    }

    @PostMapping("/{name}/delete")
    public String deleteUser(@PathVariable String name, Model model){
        if(!checkSession(name)) {
            model.addAttribute("403", name);
            return "error";
        }
        User toRemove=users.getValue(name);
        if(toRemove!=null) {
            Team userTeam = toRemove.getTeam();
            users.removeUser(name);
            if(userTeam != null && userTeam.getUsers().size()==0){          // If user was the only one in the team also delete team
                teams.removeTeam(userTeam.getName());
            }
            loginDisplay(model);
            return "index";
        }
        return "error";
    }

    private void loginDisplay(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_USER"))) {
            model.addAttribute("isLogged", true);
            if (auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
                model.addAttribute("admin", true);
            } else {
                model.addAttribute("username", users.getValue(auth.getName()));
            }
        }
    }

    private boolean checkSession(String name){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!(auth instanceof AnonymousAuthenticationToken)) {
            return auth.getName() != null && (auth.getName().equals(name) || auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN")));
        }
        return false;
    }
}
