package com.example.dws2022v1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dws2022v1Application {

	public static void main(String[] args) {
		SpringApplication.run(Dws2022v1Application.class, args);
	}

}
