package com.example.dws2022v1.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.security.SecureRandom;

@EnableWebSecurity
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    @Autowired
    RepositoryUserDetailsService userDetailsService;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(10, new SecureRandom());
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
    }

    @Override
    protected void configure(final HttpSecurity http) throws Exception {

        http.authorizeRequests().antMatchers("/users/login").permitAll();
        http.authorizeRequests().antMatchers("/users/register").permitAll();
        http.authorizeRequests().antMatchers("/users/{name}").hasAnyRole("USER","ADMIN");
        http.authorizeRequests().antMatchers("/users/{name}/editPass").hasAnyRole("USER","ADMIN");
        http.authorizeRequests().antMatchers("/users/{name}/editDesc").hasAnyRole("USER","ADMIN");
        http.authorizeRequests().antMatchers("/users/{name}/delete").hasAnyRole("USER","ADMIN");

        http.authorizeRequests().antMatchers("/teams").permitAll();
        http.authorizeRequests().antMatchers("/teams/create").hasRole("USER");
        http.authorizeRequests().antMatchers("/teams/join").hasRole("USER");
        http.authorizeRequests().antMatchers("/teams/{name}").hasAnyRole("USER","ADMIN");
        http.authorizeRequests().antMatchers("/teams/{name}/editPass").hasAnyRole("USER","ADMIN");
        http.authorizeRequests().antMatchers("/teams/{name}/editMotto").hasAnyRole("USER","ADMIN");
        http.authorizeRequests().antMatchers("/teams/{name}/delete").hasAnyRole("USER","ADMIN");

        http.authorizeRequests().antMatchers("/tournaments").permitAll();
        http.authorizeRequests().antMatchers("/tournaments/search").permitAll();
        http.authorizeRequests().antMatchers("/tournaments/{code}").permitAll();
        http.authorizeRequests().antMatchers("/tournaments/create").hasRole("ADMIN");
        http.authorizeRequests().antMatchers("/tournaments/join").hasRole("USER");
        http.authorizeRequests().antMatchers("/tournaments/{code}/editStartDate").hasRole("ADMIN");
        http.authorizeRequests().antMatchers("/tournaments/{code}/editFinishDate").hasRole("ADMIN");
        http.authorizeRequests().antMatchers("/tournaments/{code}/editBriefDescription").hasRole("ADMIN");
        http.authorizeRequests().antMatchers("/tournaments/{code}/delete").hasRole("ADMIN");

        http.authorizeRequests().antMatchers("/admin").hasRole("ADMIN");
        http.authorizeRequests().antMatchers("/").permitAll();
        http.authorizeRequests().antMatchers("/stopwatch").permitAll();

        http.formLogin().loginPage("/users/login");
        http.formLogin().usernameParameter("name");
        http.formLogin().passwordParameter("password");
        http.formLogin().failureUrl("/error");

        http.logout().logoutSuccessUrl("/");
    }
}