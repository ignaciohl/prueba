package com.example.dws2022v1.tournaments;

import com.example.dws2022v1.teams.Team;
import com.example.dws2022v1.users.User;
import com.fasterxml.jackson.annotation.JsonView;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.PreRemove;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@Entity
public class Tournament {

    public interface TournamentView{}

    @JsonView({TournamentView.class, Team.TeamView.class})
    private String tournamentName;
    @JsonView({TournamentView.class, Team.TeamView.class})
    private String institution;
    @JsonView({TournamentView.class, Team.TeamView.class})
    private Date startDate;
    @JsonView({TournamentView.class, Team.TeamView.class})
    private Date finishDate;
    @JsonView({TournamentView.class, Team.TeamView.class})
    private String briefDescription;
    @JsonView({TournamentView.class, Team.TeamView.class})
    @Id
    private String code;
    @JsonView(TournamentView.class)
    @ManyToMany(mappedBy = "tournaments")
    private List<Team> teams = new ArrayList<>();

    public Tournament(String tournamentName, String institution, Date startDate, Date finishDate, String briefDescription, String code) {
        this.tournamentName = tournamentName;
        this.institution = institution;
        this.startDate = startDate;
        this.finishDate = finishDate;
        this.briefDescription = briefDescription;
        this.code = code;
    }

    public boolean addTeam(Team team){
        if (teams.contains(team)) return false;
        teams.add(team);
        System.out.println(teams);
        return true;
    }

    public void removeTeam(Team team){
        teams.remove(team);
    }

    @PreRemove
    public void onDelete(){
        for(Team t : teams){
            t.removeTournament(this);
        }
    }

    @Override
    public String toString() {
        return "El torneo "+ tournamentName +
                " empieza el día " + startDate +
                " y termina el día " + finishDate +
                ".\nSobre el torneo:\n" + briefDescription;
    }
}
