package com.example.dws2022v1.teams;

import com.example.dws2022v1.tournaments.Tournament;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TeamRepository extends JpaRepository<Team, String> {
    @Query(value = "select * from team where (name LIKE CONCAT('%', ?1, '%'))", nativeQuery = true)
    List<Team> teamsByName(String name);
}
