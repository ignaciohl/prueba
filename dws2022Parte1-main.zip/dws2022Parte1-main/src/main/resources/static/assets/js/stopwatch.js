

//Define vars to hold time values
let seconds = 0;
let minutes = 7;

//Define vars to hold "display" value
let displaySeconds = 0;

//Define var to hold setInterval() function
let interval = null;

//Define var to hold stopwatch status
let status = "stopped";

//Sound effects
let shieldMinute = document.getElementById("shield");
let timeUp = document.getElementById("timeUp");
let overtime15 = document.getElementById("overtime");
let endAlarm = document.getElementById("end");


//Stopwatch function (logic to determine when to increment next value, etc.)
function stopWatch(){

    //Logic to determine when to decrease next value
    if(seconds === 0){
        seconds = 60;
        minutes--;
    }
    seconds--;


    //Logic to determine when to play audios (for the future)
    if ((minutes === 6 || minutes === 1) && seconds === 0) {
        shieldMinute.play();
    } else if (minutes === 0 && seconds === 0) {
        timeUp.play();
    } else if (minutes === -1 && seconds === 45) {
        overtime15.play();
    } else if (minutes === -2 && seconds === 0) {
        endAlarm.play();
    }



    //Display updated time values to user
    if (minutes > -1) { //Regular 7 minutes
        //If seconds/minutes/hours are only one digit, add a leading 0 to the value
        if(seconds < 10) {
            displaySeconds = "0" + seconds.toString();
        }
        else{
            displaySeconds = seconds;
        }
        document.getElementById("display").innerHTML = minutes.toString() + ":" + displaySeconds;
    } else if (minutes > -2) { //Overtime, 1 negative minute
        //Print reverse countdown in seconds
        displaySeconds = 60 - seconds;
        document.getElementById("display").innerHTML = "-" + displaySeconds;
    } else {
        //End the round
        reset();
    }
}

function startStop(){

    if(status === "stopped"){
        //Start the stopwatch (by calling the setInterval() function)
        interval = window.setInterval(stopWatch, 1000);
        document.getElementById("startStop").innerHTML = "Parar";
        status = "started";
    }
    else {
        window.clearInterval(interval);
        document.getElementById("startStop").innerHTML = "Reanudar";
        status = "stopped";
    }
}

//Function to reset the stopwatch
function reset(){

    window.clearInterval(interval);
    seconds = 0;
    minutes = 7;
    status = "stopped";
    document.getElementById("display").innerHTML = "7:00";
    document.getElementById("startStop").innerHTML = "Empezar";

}